using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;

namespace WireframeMod
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public class Plugin : BaseUnityPlugin
    {
        public const string PluginGuid = "com.author.wireframemod";
        public const string PluginName = "WireframeMod";
        public const string PluginVersion = "1.0.0";

        public static ConfigEntry<bool> ConfigEnabled;
        public static ConfigEntry<bool> ConfigRGB;
        public static ConfigEntry<float> ConfigRGBSpeed;
        public static ConfigEntry<float> ConfigRGBSpan;
        private Harmony _harmony;

        private void Awake()
        {
            ConfigEnabled = Config.Bind(
                "General",
                "Enabled",
                true,
                "Turn the local wireframe effect on or off.");

            ConfigRGB = Config.Bind(
                "General",
                "RGB",
                true,
                "Rainbow gradient from the top of the body to the bottom.");

            ConfigRGBSpeed = Config.Bind(
                "General",
                "RGBSpeed",
                0.25f,
                "How fast the rainbow scrolls downward (0 = static).");

            ConfigRGBSpan = Config.Bind(
                "General",
                "RGBSpan",
                1f,
                "How many full rainbows fit top to bottom.");

            _harmony = new Harmony(PluginGuid);
            _harmony.PatchAll();

            var localManagerObj = new GameObject("WireframeMod_LocalManager");
            DontDestroyOnLoad(localManagerObj);
            localManagerObj.AddComponent<WireframeLocalController>();

            Logger.LogInfo("WireframeMod (Local-Only) loaded.");
        }

        private void OnDestroy()
        {
            _harmony?.UnpatchSelf();
        }
    }
}
