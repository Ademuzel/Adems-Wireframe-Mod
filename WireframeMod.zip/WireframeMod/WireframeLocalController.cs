using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;

namespace WireframeMod
{
    public class WireframeLocalController : MonoBehaviour
    {
        private class WireEntry
        {
            public Material Mat;
            public Renderer Rend;
        }

        private readonly Dictionary<Renderer, Material[]> _originalMaterials = new Dictionary<Renderer, Material[]>();
        private readonly List<WireEntry> _wireEntries = new List<WireEntry>();
        public static Material WireframeMaterialTemplate;

        private const string BundleResourceName = "WireframeMod.Resources.wireframe";
        private const string MaterialAssetName = "Wireframe";
        private static AssetBundle _bundle;

        private float _timer;

        private void Start()
        {
            Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(BundleResourceName);
            if (stream == null) return;

            if (_bundle == null)
                _bundle = AssetBundle.LoadFromStream(stream);

            if (_bundle != null)
            {
                WireframeMaterialTemplate = _bundle.LoadAsset<Material>(MaterialAssetName);
            }
        }

        private void Update()
        {
            UpdateRGB();

            _timer += Time.deltaTime;
            if (_timer < 1f) return; // Check every 1 second
            _timer = 0f;

            if (Plugin.ConfigEnabled.Value)
            {
                ApplyWireframeToLocalRig();
            }
            else
            {
                RevertLocalRig();
            }
        }

        private void UpdateRGB()
        {
            if (_wireEntries.Count == 0) return;

            bool rgb = Plugin.ConfigRGB.Value;

            for (int i = _wireEntries.Count - 1; i >= 0; i--)
            {
                var e = _wireEntries[i];
                if (e.Mat == null) { _wireEntries.RemoveAt(i); continue; }

                e.Mat.SetFloat("_RainbowEnabled", rgb ? 1f : 0f);
                if (!rgb || e.Rend == null) continue;

                Bounds b = e.Rend.bounds;
                e.Mat.SetFloat("_RainbowTop", b.max.y);
                e.Mat.SetFloat("_RainbowHeight", b.size.y);
                e.Mat.SetFloat("_RainbowSpan", Plugin.ConfigRGBSpan.Value);
                e.Mat.SetFloat("_RainbowSpeed", Plugin.ConfigRGBSpeed.Value);
            }
        }

        private void ApplyWireframeToLocalRig()
        {
            if (WireframeMaterialTemplate == null) return;

            var allRigs = Object.FindObjectsByType<VRRig>(FindObjectsInactive.Include, FindObjectsSortMode.None);
            foreach (var rig in allRigs)
            {
                // FILTER: Only target the local player rig! Skip everyone else.
                if (rig == null || !rig.isLocal) continue;

                var renderer = FindFurRenderer(rig);
                if (renderer == null) continue;

                var mats = renderer.materials;

                // Check if your rig already has the wireframe applied
                bool alreadyHasWireframe = false;
                foreach (var mat in mats)
                {
                    if (mat != null && mat.shader == WireframeMaterialTemplate.shader)
                    {
                        alreadyHasWireframe = true;
                        break;
                    }
                }

                if (alreadyHasWireframe) continue;

                // Save original materials if we haven't tracked this renderer yet
                if (!_originalMaterials.ContainsKey(renderer))
                {
                    _originalMaterials[renderer] = (Material[])mats.Clone();
                }

                var swapped = new Material[mats.Length];
                bool swappedAny = false;

                for (int i = 0; i < mats.Length; i++)
                {
                    var mat = mats[i];
                    if (mat != null)
                    {
                        string matName = mat.name.ToLower();

                        // Only target the main gorilla body fur material on your local rig
                        if (matName.Contains("gorilla_body"))
                        {
                            Color playerColor = Color.white;
                            if (mat.HasProperty("_Color"))
                            {
                                playerColor = mat.GetColor("_Color");
                            }

                            var wireMat = new Material(WireframeMaterialTemplate);
                            wireMat.color = playerColor;
                            _wireEntries.Add(new WireEntry { Mat = wireMat, Rend = renderer });
                            swapped[i] = wireMat;
                            swappedAny = true;
                        }
                        else
                        {
                            swapped[i] = mats[i];
                        }
                    }
                }

                if (swappedAny)
                {
                    renderer.materials = swapped;
                }
            }
        }

        private void RevertLocalRig()
        {
            foreach (var kvp in _originalMaterials)
            {
                if (kvp.Key != null && kvp.Value != null)
                {
                    kvp.Key.materials = kvp.Value;
                }
            }

            foreach (var e in _wireEntries)
            {
                if (e.Mat != null) Destroy(e.Mat);
            }
            _wireEntries.Clear();

            _originalMaterials.Clear();
        }

        private Renderer FindFurRenderer(VRRig rig)
        {
            var target = FindChildRecursive(rig.transform, "gorilla_new");
            if (target == null) return null;
            return target.GetComponent<Renderer>();
        }

        private Transform FindChildRecursive(Transform parent, string name)
        {
            foreach (Transform child in parent)
            {
                if (child.name.ToLower() == name.ToLower()) return child;
                var found = FindChildRecursive(child, name);
                if (found != null) return found;
            }
            return null;
        }
    }
}
